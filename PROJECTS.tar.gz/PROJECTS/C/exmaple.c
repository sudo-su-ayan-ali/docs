#include <stdio.h>
int main(int argc, char const *argv[])
{
    printf("hekko asdf");
    return 0;
}
