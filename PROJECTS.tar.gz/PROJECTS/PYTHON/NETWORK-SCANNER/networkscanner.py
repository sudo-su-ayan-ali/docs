#made by ayan ali form class 12th science for practical exam
import nmap
import requests

def scan_network(ip_range):
    nm = nmap.PortScanner()
    nm.scan(ip_range, arguments='-sV')
    nm.scan(ip_range, arguments='-vv')
    result = {}
    for host in nm.all_hosts():
        result[host] = []
        for proto in nm[host].all_protocols():
            lport = nm[host][proto].keys()
            for port in lport:
                result[host].append({
                    'port': port,
                    'name': nm[host][proto][port]['name'],
                    'version': nm[host][proto][port]['version']
                })
    return result

def search_exploitdb(service, version):
    query = f"{service} {version}"
    url = f"https://www.exploit-db.com/search?cve={query}"
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.url
    else:
        return "No vulnerabilities found."

# Example usage
if __name__ == "__main__":
    ip_range = '192.168.1.0/24'  # Change this to your target IP range
    scan_results = scan_network(ip_range)
    for host, services in scan_results.items():
        print(f"Host: {host}")
        for service in services:
            print(f"  Port: {service['port']}, Name: {service['name']}, Version: {service['version']}")
            vulnerabilities = search_exploitdb(service['name'], service['version'])
            print("  Vulnerabilities:")
            print(f"    {vulnerabilities}")

