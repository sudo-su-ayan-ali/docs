## 📌 Table of Contents

1. Introduction to Python
2. Variables and Data Types
3. Operators
4. Control Flow (if, for, while)
5. Functions
6. Data Structures (List, Tuple, Set, Dictionary)
7. OOP (Object-Oriented Programming)
8. File Handling
9. Modules and Packages
10. Error Handling (try...except)
11. Advanced Topics (Lambdas, List Comprehensions, etc.)