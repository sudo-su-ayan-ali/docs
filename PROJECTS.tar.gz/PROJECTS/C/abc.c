#include <stdio.h>
int main()
{
	printf("hekkfsldaf");
	return 0;
}