| Time                | Activity                                                        |
| ------------------- | --------------------------------------------------------------- |
| **4:30 – 5:00 AM**  | 🕌 **Fajr Prayer**                                              |
| **5:00 – 5:45 AM**  | 🚿 Freshen Up + Light Breakfast                                 |
| **5:45 – 8:00 AM**  | 🏋️‍♂️ Workout / Physical Exercise                              |
| **8:00 – 9:00 AM**  | 🍳 Full Breakfast + Short Rest                                  |
| **9:00 – 11:00 AM** | 🛡️ Web Security Learning (YouTube + PortSwigger Labs)          |
| **11:00 – 1:00 PM** | 🎯 CTFs on TryHackMe / HackTheBox                               |
| **1:00 – 2:30 PM**  | 🍽️ Lunch + 🕌 **Dhuhr Prayer** + 20-min Power Nap              |
| **2:30 – 5:30 PM**  | 🐍 Python Programming / Building Projects                       |
| **5:30 – 6:00 PM**  | ☕ Tea Break + Light Rest                                        |
| **5:45 – 6:15 PM**  | 🕌 **Asr Prayer** (Adjusted for Sirohi Azan time)               |
| **6:15 – 7:15 PM**  | 🚶 Light Walk / Social Time / Free Time                         |
| **7:30 – 8:00 PM**  | 🕌 **Maghrib Prayer**                                           |
| **8:00 – 9:00 PM**  | 📘 Read _Art of Exploitation – 2nd Edition_                     |
| **9:00 – 9:30 PM**  | 🍽️ Dinner                                                      |
| **9:30 – 10:15 PM** | 🕌 **Isha Prayer** + Du’a / Reflection                          |
| **10:15 – 4:30 AM** | 💤 Sleep (6 hrs 15 mins) – solid for memory, energy & alertness |