### CATEGORY (INJECTION)
### THIS NOTES ARE TOTALLY DEDICATED ABOUT XSS TECHNIQUES AND BYPASSES FOR CSPs AND MUCH MORE. WE LEARN AND PRACTICE ON PORTSWIGGER. START FROM NOW ITS ALL ABOUT EGO TO DON'T FORGOT IT.
## LAB: Reflected XSS into HTML context with nothing encoded
- PAYLOAD ````<script>alert(1)</script>````
- THE INPUT FIELD IN URL  `?search=`
- THIS HOW IT SEEMS TO BE AFTER  INJECTING THE PAYLOAD ```https://0a51009003d73e1c8079588a008a00c9.web-security-academy.net/?search=%3Cscript%3Ealert%281%29%3C%2Fscript%3E```
- AND AFTER INJECTING THE PAYLOAD. THE WEB SHOWS A POP UP LIKE THIS
## LAB: Stored XSS into HTML context with nothing encoded
1. Enter the following into the comment box:
    ``<script>alert(1)</script>``
2. Enter a name, email and website.
3. Click "Post comment".
4. Go back to the blog.
## LAB: # DOM XSS in `document.write` sink using source `location.search`
1. Enter a random alphanumeric string into the search box.
2. Right-click and inspect the element, and observe that your random string has been placed inside an `img src` attribute.
3. Break out of the `img` attribute by searching for:
    `"><svg onload=alert(1)>`
## LAB: DOM XSS in `innerHTML` sink using source `location.search`
1. Enter the following into the into the search box:
    
    `<img src=1 onerror=alert(1)>`
2. Click "Search".
	The value of the `src` attribute is invalid and throws an error. This triggers the `onerror` event handler, which then calls the `alert()` function. As a result, the payload is executed whenever the user's browser attempts to load the page containing your malicious post.
## LAB: DOM XSS in jQuery anchor `href` attribute sink using `location.search` source
1. On the Submit feedback page, change the query parameter `returnPath` to `/` followed by a random alphanumeric string.
2. Right-click and inspect the element, and observe that your random string has been placed inside an a `href` attribute.
3. Change `returnPath` to:
    `javascript:alert(document.cookie)`
4. Hit enter and click "back".
## LAB: DOM XSS in jQuery selector sink using a hashchange event
1. Notice the vulnerable code on the home page using Burp or the browser's DevTools.
2. From the lab banner, open the exploit server.
3. In the **Body** section, add the following malicious `iframe`:
    
    `<iframe src="https://YOUR-LAB-ID.web-security-academy.net/#" onload="this.src+='<img src=x onerror=print()>'"></iframe>`
4. Store the exploit, then click **View exploit** to confirm that the `print()` function is called.
5. Go back to the exploit server and click **Deliver to victim** to solve the lab.
## LAB: Reflected XSS into attribute with angle brackets HTML-encoded
1. Submit a random alphanumeric string in the search box, then use Burp Suite to intercept the search request and send it to Burp Repeater.
2. Observe that the random string has been reflected inside a quoted attribute.
3. Replace your input with the following payload to escape the quoted attribute and inject an event handler:
    
    `"onmouseover="alert(1)`
4. Verify the technique worked by right-clicking, selecting "Copy URL", and pasting the URL in the browser. When you move the mouse over the injected element it should trigger an alert.
## LAB: Stored XSS into anchor `href` attribute with double quotes HTML-encoded
1. Post a comment with a random alphanumeric string in the "Website" input, then use Burp Suite to intercept the request and send it to Burp Repeater.
2. Make a second request in the browser to view the post and use Burp Suite to intercept the request and send it to Burp Repeater.
3. Observe that the random string in the second Repeater tab has been reflected inside an anchor `href` attribute.
4. Repeat the process again but this time replace your input with the following payload to inject a JavaScript URL that calls alert:
    
    `javascript:alert(1)`
5. Verify the technique worked by right-clicking, selecting "Copy URL", and pasting the URL in the browser. Clicking the name above your comment should trigger an alert.
## LAB: DOM XSS in `document.write` sink using source `location.search` inside a select element
1. On the product pages, notice that the dangerous JavaScript extracts a `storeId` parameter from the `location.search` source. It then uses `document.write` to create a new option in the select element for the stock checker functionality.
2. Add a `storeId` query parameter to the URL and enter a random alphanumeric string as its value. Request this modified URL.
3. In the browser, notice that your random string is now listed as one of the options in the drop-down list.
4. Right-click and inspect the drop-down list to confirm that the value of your `storeId` parameter has been placed inside a select element.
5. Change the URL to include a suitable XSS payload inside the `storeId` parameter as follows:
    
    `product?productId=1&storeId="></select><img%20src=1%20onerror=alert(1)>`
## LAB: DOM XSS in AngularJS expression with angle brackets and double quotes HTML-encoded
1. Enter a random alphanumeric string into the search box.
2. View the page source and observe that your random string is enclosed in an `ng-app` directive.
3. Enter the following AngularJS expression in the search box:
    
    `{{$on.constructor('alert(1)')()}}`
4. Click **search**.
## LAB: Reflected DOM XSS
1. In Burp Suite, go to the Proxy tool and make sure that the Intercept feature is switched on.
2. Back in the lab, go to the target website and use the search bar to search for a random test string, such as `"XSS"`.
3. Return to the Proxy tool in Burp Suite and forward the request.
4. On the Intercept tab, notice that the string is reflected in a JSON response called `search-results`.
5. From the Site Map, open the `searchResults.js` file and notice that the JSON response is used with an `eval()` function call.
6. By experimenting with different search strings, you can identify that the JSON response is escaping quotation marks. However, backslash is not being escaped.
7. To solve this lab, enter the following search term:
    
    `\"-alert(1)}//`
8. As you have injected a backslash and the site isn't escaping them, when the JSON response attempts to escape the opening double-quotes character, it adds a second backslash. The resulting double-backslash causes the escaping to be effectively canceled out. This means that the double-quotes are processed unescaped, which closes the string that should contain the search term.

9. An arithmetic operator (in this case the subtraction operator) is then used to separate the expressions before the `alert()` function is called. Finally, a closing curly bracket and two forward slashes close the JSON object early and comment out what would have been the rest of the object. As a result, the response is generated as follows:

10. `{"searchTerm":"\\"-alert(1)}//", "results":[]}`
## LAB: Stored DOM XSS
1. Post a comment containing the following vector:
2. `<><img src=1 onerror=alert(1)>`
3. In an attempt to prevent XSS, the website uses the JavaScript `replace()` function to encode angle brackets. However, when the first argument is a string, the function only replaces the first occurrence. We exploit this vulnerability by simply including an extra set of angle brackets at the beginning of the comment. These angle brackets will be encoded, but any subsequent angle brackets will be unaffected, enabling us to effectively bypass the filter and inject HTML.
## LAB: Reflected XSS into HTML context with most tags and attributes blocked
1. Inject a standard XSS vector, such as:
    
    `<img src=1 onerror=print()>`
2. Observe that this gets blocked. In the next few steps, we'll use use Burp Intruder to test which tags and attributes are being blocked.
3. Open Burp's browser and use the search function in the lab. Send the resulting request to Burp Intruder.
4. In Burp Intruder, replace the value of the search term with: `<>`
5. Place the cursor between the angle brackets and click **Add §** to create a payload position. The value of the search term should now look like: `<§§>`
6. Visit the [XSS cheat sheet](https://portswigger.net/web-security/cross-site-scripting/cheat-sheet) and click **Copy tags to clipboard**.
7. In the **Payloads** side panel, under **Payload configuration**, click **Paste** to paste the list of tags into the payloads list. Click **Start attack**.
8. When the attack is finished, review the results. Note that most payloads caused a `400` response, but the `body` payload caused a `200` response.
9. Go back to Burp Intruder and replace your search term with:
    
    `<body%20=1>`
10. Place the cursor before the `=` character and click **Add §** to create a payload position. The value of the search term should now look like: `<body%20§§=1>`
11. Visit the [XSS cheat sheet](https://portswigger.net/web-security/cross-site-scripting/cheat-sheet) and click **Copy events to clipboard**.
12. In the **Payloads** side panel, under **Payload configuration**, click **Clear** to remove the previous payloads. Then click **Paste** to paste the list of attributes into the payloads list. Click **Start attack**.
13. When the attack is finished, review the results. Note that most payloads caused a `400` response, but the `onresize` payload caused a `200` response.
14. Go to the exploit server and paste the following code, replacing `YOUR-LAB-ID` with your lab ID:
    
    `<iframe src="https://YOUR-LAB-ID.web-security-academy.net/?search=%22%3E%3Cbody%20onresize=print()%3E" onload=this.style.width='100px'>`
15. Click **Store** and **Deliver exploit to victim**.
## LAB: Reflected XSS into HTML context with all tags blocked except custom ones
1. Go to the exploit server and paste the following code, replacing `YOUR-LAB-ID` with your lab ID:
    
    `<script> location = 'https://YOUR-LAB-ID.web-security-academy.net/?search=%3Cxss+id%3Dx+onfocus%3Dalert%28document.cookie%29%20tabindex=1%3E#x'; </script>`
2. Click "Store" and "Deliver exploit to victim".
3. This injection creates a custom tag with the ID `x`, which contains an `onfocus` event handler that triggers the `alert` function. The hash at the end of the URL focuses on this element as soon as the page is loaded, causing the `alert` payload to be called.
