#include<stdio.h> //header files
int main() //main function
{
    // printf("Hello World!");
    // int a;
    // scanf("%d",&a); // Store keyboard input in a variable with address (address of a or &a)
    // printf("%d",a);
    // This is a single line comment
    /* This is a 
    multi-line
    comment
    */
   // str variables or charactor variables
 
   float c;
   scanf("%f",&c);
   printf("%f",c);
   
   
   
   return(0); //returning value to int main()
}