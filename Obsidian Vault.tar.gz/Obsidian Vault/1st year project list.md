+## 🧠 Beginner-Friendly Python Cybersecurity Projects

### 1. **Password Strength Checker**

- **Goal**: Detect weak passwords using rules (length, symbols, etc.)
    
- **Learn**:
    
    - Regex (`re` module)
        
    - Basic logic conditions
        
- **Extra**: Use `zxcvbn` (password strength estimator by Dropbox)
    

---

### 2. **Simple Port Scanner**

- **Goal**: Scan common ports on a target IP
    
- **Learn**:
    
    - `socket` module
        
    - IP & Port basics
        
- **Extra**: Add banner grabbing (e.g., using `socket.recv()`)
    

---

### 3. **Keylogger (for education only)**

- **Goal**: Capture keystrokes and save to a file
    
- **Learn**:
    
    - `pynput` or `keyboard` module
        
    - Working with files
        
- ⚠️ **Warning**: Never use on other systems; use in your **lab environment** only.
    

---

### 4. **Basic Encryption/Decryption Tool**

- **Goal**: Encrypt and decrypt text using Caesar, XOR, or simple AES
    
- **Learn**:
    
    - `cryptography` or `pycryptodome` module
        
    - Encoding/decoding logic
        
- **Extra**: Add password-protected encryption
    

---

### 5. **Simple Hash Cracker (Dictionary Attack)**

- **Goal**: Crack MD5/SHA-1 hash using wordlists
    
- **Learn**:
    
    - `hashlib` module
        
    - File I/O and loops
        
- **Extra**: Load rockyou.txt or your own wordlist
    

---

### 6. **WHOIS & IP Geolocation Tool**

- **Goal**: Get domain/IP ownership and geolocation info
    
- **Learn**:
    
    - `whois` module
        
    - APIs like ipinfo.io or ipapi
        
- **Extra**: Use `argparse` for CLI inputs
    

---

### 7. **Basic Network Sniffer**

- **Goal**: Capture packets using raw sockets
    
- **Learn**:
    
    - `scapy` module
        
    - Packet structures
        
- **Extra**: Filter HTTP or DNS requests
    

---

### 8. **Fake Login Page Detector**

- **Goal**: Check if a page is trying to steal credentials (phishing detection logic)
    
- **Learn**:
    
    - Requests, BeautifulSoup
        
    - URL parsing and form tag detection
        

---

### 9. **Simple File Integrity Checker**

- **Goal**: Monitor if files are modified (hash comparison)
    
- **Learn**:
    
    - `hashlib`
        
    - File monitoring basics
        
- **Extra**: Add directory scan + alert system
    

---

### 10. **Secure Password Generator**

- **Goal**: Create complex passwords with user-defined rules
    
- **Learn**:
    
    - `random` or `secrets` module
        
    - String manipulation
        
